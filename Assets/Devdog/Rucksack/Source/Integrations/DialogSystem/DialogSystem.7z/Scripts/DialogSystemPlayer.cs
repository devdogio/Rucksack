﻿using UnityEngine;

using PixelCrushers.DialogueSystem;

using Devdog.Rucksack.CharacterEquipment;
using Devdog.Rucksack.Characters;
using Devdog.Rucksack.Items;
using System;
using Devdog.Rucksack.CharacterEquipment.Items;
using Devdog.Rucksack.Collections;

namespace Devdog.Rucksack.Integrations.DialogSystem
{

	[RequireComponent(typeof(InventoryPlayer), typeof(UnityEquippableCharacter))]
	public class DialogSystemPlayer : MonoBehaviour
	{
		private InventoryPlayer inventoryPlayer;
		private UnityEquippableCharacter equippableCharacter;

		public void Awake()
		{
			inventoryPlayer = GetComponent<InventoryPlayer>();
			equippableCharacter = GetComponent<UnityEquippableCharacter>();
		}

		public void Start()
		{
			Lua.RegisterFunction("CanAddCurrency", this, SymbolExtensions.GetMethodInfo(() => CanAddCurrency(string.Empty, 0)));
			Lua.RegisterFunction("AddCurrency", this, SymbolExtensions.GetMethodInfo(() => AddCurrency(string.Empty, 0)));

			Lua.RegisterFunction("CanRemoveCurrency", this, SymbolExtensions.GetMethodInfo(() => CanRemoveCurrency(string.Empty, 0)));
			Lua.RegisterFunction("RemoveCurrency", null, SymbolExtensions.GetMethodInfo(() => RemoveCurrency(string.Empty, 0)));
			Lua.RegisterFunction("GetCurrency", null, SymbolExtensions.GetMethodInfo(() => GetCurrencyCount(string.Empty)));

			Lua.RegisterFunction("CanAddItem", null, SymbolExtensions.GetMethodInfo(() => CanAddItem(string.Empty, 0)));
			Lua.RegisterFunction("AddItem", null, SymbolExtensions.GetMethodInfo(() => AddItem(string.Empty, 0)));
			Lua.RegisterFunction("CanRemoveItem", null, SymbolExtensions.GetMethodInfo(() => CanRemoveItem(string.Empty, 0)));

			Lua.RegisterFunction("RemoveItem", null, SymbolExtensions.GetMethodInfo(() => RemoveItem(string.Empty, 0)));
			Lua.RegisterFunction("GetItemCount", null, SymbolExtensions.GetMethodInfo(() => GetItemCount(string.Empty)));

			Lua.RegisterFunction("EquipItem", this, SymbolExtensions.GetMethodInfo(() => EquipItem(string.Empty, 0)));
			Lua.RegisterFunction("UnEquipItem", this, SymbolExtensions.GetMethodInfo(() => UnEquipItem(string.Empty, 0)));

			foreach(var collectionName in inventoryPlayer.itemCollections)
			{
				var collection = ( ICollection<IItemInstance>) CollectionRegistry.byName.Get(collectionName);

				collection.OnAddedItem += CollectionOnAddedItem;
				collection.OnRemovedItem += CollectionOnRemovedItem;
			}
		}

		private void CollectionOnRemovedItem(object sender, CollectionRemoveResult e)
		{
			throw new NotImplementedException();
		}

		private void CollectionOnAddedItem(object sender, CollectionAddResult e)
		{
			throw new NotImplementedException();
		}

		private bool EquipItem(string guid, int amount)
		{
			var item = DialogSystemUtilities.ItemByGuid(guid) as IEquippableItemInstance;

			return equippableCharacter.Equip(item, amount).error == null;
		}

		private bool UnEquipItem(string guid, int amount)
		{
			var item = DialogSystemUtilities.ItemByGuid(guid) as IEquippableItemInstance;

			return equippableCharacter.UnEquip(item, amount).error == null;
		}

		private bool CanAddCurrency(string currencyName, double amount)
		{
			var currency = DialogSystemUtilities.CurrencyByName(currencyName);

			return inventoryPlayer.currencyCollectionGroup.CanAdd(currency, amount).result;
		}

		private bool CanRemoveCurrency(string currencyName, double amount)
		{
			var currency = DialogSystemUtilities.CurrencyByName(currencyName);

			return inventoryPlayer.currencyCollectionGroup.CanRemove(currency, amount).result;
		}

		private bool AddCurrency(string currencyName, double amount)
		{
			var currency = DialogSystemUtilities.CurrencyByName(currencyName);

			return inventoryPlayer.currencyCollectionGroup.Add(currency, amount).result;
		}

		private bool RemoveCurrency(string currencyName, double amount)
		{
			var currency = DialogSystemUtilities.CurrencyByName(currencyName);

			return inventoryPlayer.currencyCollectionGroup.Remove(currency, amount).result;
		}

		public double GetCurrencyCount(string currencyName)
		{
			var currency = DialogSystemUtilities.CurrencyByName(currencyName);

			return inventoryPlayer.currencyCollectionGroup.GetAmount(currency);
		}

		private bool CanAddItem(string guid, int amount)
		{
			var item = DialogSystemUtilities.ItemByGuid(guid);

			return inventoryPlayer.itemCollectionGroup.CanAdd(item, amount).result;
		}

		private bool CanRemoveItem(string guid, int amount)
		{
			var item = DialogSystemUtilities.ItemByGuid(guid);

			return inventoryPlayer.itemCollectionGroup.CanRemove(item, amount).result;
		}

		private bool AddItem(string guid, int amount)
		{
			var item = DialogSystemUtilities.ItemByGuid(guid);

			return inventoryPlayer.itemCollectionGroup.Add(item, amount).error == null;
		}

		private bool RemoveItem(string guid, int amount)
		{
			var item = DialogSystemUtilities.ItemByGuid(guid);

			return inventoryPlayer.itemCollectionGroup.Remove(item, amount).error == null;
		}



		public int GetItemCount(string name)
		{
			var item = DialogSystemUtilities.ItemByGuid(name);

			return inventoryPlayer.itemCollectionGroup.GetAmount(item);
		}
	}
}
 