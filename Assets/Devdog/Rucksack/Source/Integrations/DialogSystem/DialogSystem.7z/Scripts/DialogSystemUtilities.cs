﻿using Devdog.Rucksack.Characters;
using Devdog.Rucksack.Currencies;
using Devdog.Rucksack.Items;
using Devdog.Rucksack.Database;

using Devdog.Rucksack.Vendors;
using Devdog.General2;
using System;

namespace Devdog.Rucksack.Integrations.DialogSystem
{
	public static class DialogSystemUtilities
	{
		public static IItemInstance ItemByGuid(string guid)
		{
			return ItemRegistry.Get(new System.Guid(guid));
		}

		public static ICurrency CurrencyByName(string name)
		{
			return UnityDatabaseManager.CurrencyByName(name).result;
		}

		public static Customer<IItemInstance> GetCurrentPlayerAsCustomer()
		{
			var player = PlayerManager.currentPlayer;
			var inventoryPlayer = player.GetComponent<InventoryPlayer>();

			Customer<IItemInstance> customer = new Customer<IItemInstance>(
				Guid.NewGuid(),
				player,
				inventoryPlayer.itemCollectionGroup,
				inventoryPlayer.currencyCollectionGroup);

			return customer;
		}

		public static IVendorProduct<IItemInstance> ItemToVendorProduct(IItemInstance item)
		{
			return new VendorProduct<IItemInstance>(item, item.itemDefinition.buyPrice, item.itemDefinition.sellPrice);
		}
	}
}
 