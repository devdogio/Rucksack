﻿using UnityEngine;

using PixelCrushers.DialogueSystem;
using Devdog.Rucksack.Items;

using Devdog.Rucksack.Vendors;

namespace Devdog.Rucksack.Integrations.DialogSystem
{
	[RequireComponent(typeof(ItemVendorCreator))]
	public class DialogSystemVendor : MonoBehaviour
	{
		Vendor<IItemInstance> vendor;

		public void Awake()
		{
			vendor = GetComponent<ItemVendorCreator>().vendor;
		}

		public void Start()
		{
			Lua.RegisterFunction("CanBuyFromVendor", this, SymbolExtensions.GetMethodInfo(() => CanBuyFromVendor(string.Empty, 0)));
			Lua.RegisterFunction("CanSellToVendor", this, SymbolExtensions.GetMethodInfo(() => CanBuyFromVendor(string.Empty, 0)));
			Lua.RegisterFunction("SellToVendor", this, SymbolExtensions.GetMethodInfo(() => SellToVendor(string.Empty, 0)));
			Lua.RegisterFunction("BuyFromVendor", this, SymbolExtensions.GetMethodInfo(() => BuyFromVendor(string.Empty, 0)));
		}

		private int BuyFromVendor(string guid, int amount)
		{
			var item = DialogSystemUtilities.ItemByGuid(guid);

			return vendor.BuyFromVendor(DialogSystemUtilities.GetCurrentPlayerAsCustomer(), item, amount).result.amount;
		}

		private int SellToVendor(string guid, int amount)
		{
			var item = DialogSystemUtilities.ItemToVendorProduct(DialogSystemUtilities.ItemByGuid(guid));

			return vendor.SellToVendor(DialogSystemUtilities.GetCurrentPlayerAsCustomer(), item, amount).result.amount;
		}

		private bool CanBuyFromVendor(string guid, int amount)
		{
			var item = DialogSystemUtilities.ItemByGuid(guid);

			return vendor.CanBuyFromVendor(DialogSystemUtilities.GetCurrentPlayerAsCustomer(), item, amount).result;
		}

		private bool CanSellToVendor(string guid, int amount)
		{
			var item = DialogSystemUtilities.ItemToVendorProduct(DialogSystemUtilities.ItemByGuid(guid));

			return vendor.CanSellToVendor(DialogSystemUtilities.GetCurrentPlayerAsCustomer(), item, amount).result;
		}
	}
}
 