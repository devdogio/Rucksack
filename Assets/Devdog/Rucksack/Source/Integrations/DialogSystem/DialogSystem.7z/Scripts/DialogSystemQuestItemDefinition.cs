﻿using UnityEngine;

using PixelCrushers.DialogueSystem;
using Devdog.Rucksack.Items;

namespace Devdog.Rucksack.Integrations.DialogSystem
{
	public class DialogSystemQuestItemDefinition : UnityItemDefinition
	{
		[SerializeField]
		private int _dialogueSystemQuestID = 0;

		[SerializeField]
		private bool _canUseAfterQuestAlreadyCompleted = true;

		[SerializeField]
		[ConversationPopup(true)]
		public string _customConversation = string.Empty;

		public string customConversation
		{
			get
			{
				return _customConversation;
			}
		}

		public int dialogueSystemQuestID
		{
			get
			{
				return _dialogueSystemQuestID;
			}
		}

		public bool canUseAfterQuestAlreadyCompleted
		{
			get
			{
				return _canUseAfterQuestAlreadyCompleted;
			}
		}

	}
}
 