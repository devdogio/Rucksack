﻿namespace Devdog.Rucksack.Integrations.DialogSystem
{
	public static class DialogSystemErrors
	{
		public static Error CouldNotFindDialogController =
			new Error(3001, "Couldn't find DialogueSystemController; Can't activate quest!");

		public static Error CouldNotFindDialogQuest =
			new Error(3002, "Couldn't find dialogue quest with ID {0}");

		public static Error ItemIsNotAQuest =
			new Error(3003, "Dialogue quest with ID {0} is an item, not a quest");

		public static Error QuestAlreadyActive =
			new Error(3004, "The quest \"{0}\" is already active");

		public static Error QuestAlreadyUsed =
			new Error(3005, "The quest \"{0}\" has already been used");

		public static Error NoConversationSet =
			new Error(3006, "No conversation set for {0}");
	}
}
 