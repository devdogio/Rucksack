﻿using UnityEngine;

using PixelCrushers.DialogueSystem;
using Devdog.Rucksack.Items;
using Devdog.General2;
using System.Linq;
using System;

namespace Devdog.Rucksack.Integrations.DialogSystem
{
	public class DialogSystemQuestItemInstance : UnityItemInstance
	{

		public DialogSystemQuestItemDefinition dsDefinition
		{
			get
			{
				return (DialogSystemQuestItemDefinition) this.itemDefinition;
			}
		}

		public DialogSystemQuestItemInstance(Guid guid, IUnityItemDefinition itemDefinition):base(guid, itemDefinition)
		{

		}

		public override Result<ItemUsedResult> DoUse(Character character, ItemContext useContext)
		{
			var dialogueController = UnityEngine.Object.FindObjectOfType<DialogueSystemController>();

			if (dialogueController == null)
			{
				return DialogSystemErrors.CouldNotFindDialogController;
			}

			var item = dialogueController
				.DatabaseManager
				.MasterDatabase
				.items
				.FirstOrDefault(o => o.id == dsDefinition.dialogueSystemQuestID);

			if (item == null)
			{
				return DialogSystemErrors.CouldNotFindDialogQuest.WithParams(dsDefinition.dialogueSystemQuestID);
			}

			if (item.IsItem)
			{
				return DialogSystemErrors.ItemIsNotAQuest.WithParams(dsDefinition.dialogueSystemQuestID);
			}


			if (string.IsNullOrEmpty(dsDefinition.customConversation))
			{
				return DialogSystemErrors.NoConversationSet.WithParams(dsDefinition.name);
			}

			if (QuestLog.IsQuestActive(item.Name))
			{
				PlayConversation(dialogueController, character);
				return DialogSystemErrors.QuestAlreadyActive.WithParams(item.Name);
			}

			if (QuestLog.IsQuestDone(item.Name) || QuestLog.IsQuestFailed(item.Name) || QuestLog.IsQuestAbandoned(item.Name))
			{
				if (!dsDefinition.canUseAfterQuestAlreadyCompleted)
				{
					PlayConversation(dialogueController, character);
					return DialogSystemErrors.QuestAlreadyActive;
				}
			}

			PlayConversation(dialogueController, character);

			QuestLog.StartQuest(item.Name);
			QuestLog.AddQuestStateObserver(item.Name, LuaWatchFrequency.EveryDialogueEntry, QuestChangedHandler);
			

			return new ItemUsedResult(1, true, 0); // 1 item used
		}

		private void PlayConversation(DialogueSystemController dialogueController, Character character)
		{
			dialogueController.StartConversation(dsDefinition.customConversation, character.transform);
		}

		private void QuestChangedHandler(string title, QuestState newState)
		{
			if (newState == QuestState.Success)
			{
				Debug.Log("Quest completed callback");
			}
		}
	}
}
 