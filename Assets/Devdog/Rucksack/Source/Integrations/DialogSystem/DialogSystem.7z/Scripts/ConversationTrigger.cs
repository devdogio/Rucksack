﻿using Devdog.General2;
using Devdog.Rucksack.Items;
using PixelCrushers.DialogueSystem;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class ConversationTrigger : MonoBehaviour
{
	[Tooltip("The trigger will fire only when the line spoken has this line tag")]
	public string lineTag;

	public void OnLine(Subtitle line)
	{
		var field = line.dialogueEntry.fields.FirstOrDefault(f => f.title == "LineTag");

		if (field != null && field.value == lineTag)
		{
			var character = line.speakerInfo.transform.GetComponent<Character>();

			GetComponent<Trigger>().Use(character);
		}
	}
}
