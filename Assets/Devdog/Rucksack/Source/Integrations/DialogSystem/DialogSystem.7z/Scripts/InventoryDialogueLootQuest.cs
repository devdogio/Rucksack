﻿using UnityEngine;

using PixelCrushers.DialogueSystem;
using Devdog.Rucksack.Items;

namespace Devdog.Rucksack.Integrations.DialogSystem
{
	public class InventoryDialogueLootQuest : MonoBehaviour
	{
		/// <summary>
		/// The variable to increment.
		/// </summary>
		public string variable = string.Empty;
		public ItemDefinition requiredItem;
		public int requiredAmount;

		public string alertMessage = string.Empty;


		//private ItemCollectionBase[] _collections = new ItemCollectionBase[0];

		private uint _currentCount = 0;

		protected string actualVariableName
		{
			get { return string.IsNullOrEmpty(variable) ? OverrideActorName.GetInternalName(transform) : variable; }
		}

		

		private void UpdateCount(uint itemID)
		{
			//_currentCount = InventoryManager.GetItemCount(itemID, false);

			DialogueLua.SetVariable(actualVariableName, (int)_currentCount);
			DialogueManager.SendUpdateTracker();

			if (!string.IsNullOrEmpty(alertMessage))
			{
				DialogueManager.ShowAlert(alertMessage);
			}
		}
	}
}
 