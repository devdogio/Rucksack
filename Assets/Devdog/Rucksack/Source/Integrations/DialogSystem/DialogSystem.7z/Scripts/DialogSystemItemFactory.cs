﻿using UnityEngine;
using Devdog.Rucksack.Items;

namespace Devdog.Rucksack.Integrations.DialogSystem
{
	public class DialogSystemItemFactory : MonoBehaviour
	{
		public void Awake()
		{
			ItemFactory.Bind<DialogSystemQuestItemDefinition, DialogSystemQuestItemInstance>();
		}
	}
}
 