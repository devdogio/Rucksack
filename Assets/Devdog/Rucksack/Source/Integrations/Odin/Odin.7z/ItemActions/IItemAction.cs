﻿using Devdog.General2;
using Devdog.Rucksack.Items;

namespace Devdog.Rucksack.Integrations.Odin
{
    public interface IItemAction
    {
        void Use(Character character, ItemContext useContext);
    }
}

