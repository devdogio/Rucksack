﻿using Devdog.General2;
using Devdog.Rucksack.Items;
using UnityEngine;

namespace Devdog.Rucksack.Integrations.Odin
{
    public sealed class ItemActionPlayAnimation : IItemAction
    {

        [SerializeField]
        private MotionInfo _motionInfo;
        
        public void Use(Character character, ItemContext useContext)
        {
            var source = character.GetComponent<Animator>();
            if (source != null)
            {
                source.Play(_motionInfo);
            }
            else
            {
                new UnityLogger("[Item] ").Warning("No Animator found on character. Can't play animation", character);
            }
        }
    }
}