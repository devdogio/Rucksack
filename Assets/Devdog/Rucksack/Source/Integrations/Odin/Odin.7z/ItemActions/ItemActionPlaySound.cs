﻿using Devdog.General2;
using Devdog.Rucksack.Items;
using UnityEngine;

namespace Devdog.Rucksack.Integrations.Odin
{
    public sealed class ItemActionPlaySound : IItemAction
    {

        [SerializeField]
        private AudioClipInfo _audioClip;
        
        public void Use(Character character, ItemContext useContext)
        {
            var source = character.GetComponent<AudioSource>();
            if (source != null)
            {
                source.Play(_audioClip);
            }
            else
            {
                AudioManager.AudioPlayOneShot(_audioClip);
            }
        }
    }
}