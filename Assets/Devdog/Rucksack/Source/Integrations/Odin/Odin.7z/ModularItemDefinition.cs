﻿#if ODIN_INSPECTOR

using System;
using Devdog.Rucksack.Items;
using Sirenix.OdinInspector;
using Sirenix.Serialization;
using UnityEngine;

namespace Devdog.Rucksack.Integrations.Odin
{
    [CreateAssetMenu(menuName = RucksackConstants.AddPath + "Modular Item Definition")]
    [ShowOdinSerializedPropertiesInInspector]
    public partial class ModularItemDefinition : UnityItemDefinition, ISerializationCallbackReceiver, ISupportsPrefabSerialization
    {
        [SerializeField]
        private IItemAction[] _itemActions = new IItemAction[0];
        public IItemAction[] itemActions
        {
            get { return this.GetValue(t => t._itemActions, new IItemAction[0]); }
        }


        [SerializeField]
        [HideInInspector]
        private SerializationData serializationData;
        SerializationData ISupportsPrefabSerialization.SerializationData
        {
            get
            {
                return this.serializationData;
            }
            set
            {
                this.serializationData = value;
            }
        }
        
//        public static bool operator ==(ModularItemDefinition left, ModularItemDefinition right)
//        {
//            return Equals(left, right);
//        }
//
//        public static bool operator !=(ModularItemDefinition left, ModularItemDefinition right)
//        {
//            return !Equals(left, right);
//        }
        
        public override void OnAfterDeserialize()
        {
            UnitySerializationUtility.DeserializeUnityObject((UnityEngine.Object) this, ref this.serializationData, (DeserializationContext) null);
//            this.OnAfterDeserialize();
        }

        public override void OnBeforeSerialize()
        {
            UnitySerializationUtility.SerializeUnityObject((UnityEngine.Object) this, ref this.serializationData, false, (SerializationContext) null);
//            this.OnBeforeSerialize();
        }
    }
}

#endif