﻿//#if ODIN_INSPECTOR
//
////using System;
////using System.Collections.Generic;
////using System.Linq;
////using System.Reflection;
////using Devdog.General2.Editors;
////using Devdog.Rucksack.Items;
////using Sirenix.OdinInspector;
////using Sirenix.OdinInspector.Editor;
////using UnityEditor;
////using UnityEngine;
//
//namespace Devdog.Rucksack.Integrations.Odin.Editor
//{
//    [CustomEditor(typeof(ModularItemDefinition), true)]
//    public class ModularItemDefinitionEditor : Sirenix.OdinInspector.Editor.OdinEditor
//    {
////        protected readonly ILogger logger;
////        protected readonly List<InspectorProperty> properties = new List<InspectorProperty>();
////
////        protected static UnityEditor.Editor modelPreviewEditor;
////
////        private InspectorProperty _parent;
////        private InspectorProperty _guid;
////        private InspectorProperty _name;
////        private InspectorProperty _description;
////        private InspectorProperty _maxStackSize;
////        private InspectorProperty _layoutShape;
////        private InspectorProperty _buyPrice;
////        private InspectorProperty _sellPrice;
////        private InspectorProperty _weight;
////        private InspectorProperty _icon;
////        private InspectorProperty _worldModel;
////
////        public ModularItemDefinitionEditor()
////        {
////            logger = new UnityLogger("[Editor] ");
////        }
//
////        protected override void DrawTree()
////        {
////            FindProperties();
////            EditorGUILayout.LabelField(new GUIContent("Type: " + target.GetType().Name));
////
////            var t = (UnityItemDefinition) target;
////            var overrides = new Dictionary<string, Action<InspectorProperty>>();
////            
////            EditorGUILayout.LabelField(new GUIContent("General item info"), General2.Editors.EditorStyles.titleStyle);
////            using (new VerticalLayoutBlock(General2.Editors.EditorStyles.boxStyle))
////            {
////                DrawPropertyOrOverride(_parent, t.parent, overrides);
//////                if (Equals(_parent.ValueEntry., t) || ReferenceEquals(_parent.objectReferenceValue, t) || t.Equals(_parent.objectReferenceValue))
//////                {
//////                    _parent.objectReferenceValue = null;
//////                }
////                
////                DrawReadOnlyPropertyOrOverride(_guid, t.ID, overrides);
////                DrawPropertyOrOverride(_name, t.name, overrides);
////                DrawPropertyOrOverride(_description, t.description, overrides);
////                DrawPropertyOrOverride(_icon, t.icon, overrides);
//////                if (t.icon != null)
//////                {
//////                    DrawSprite(GUILayoutUtility.GetRect(32, 32), t.icon);
//////                }
////                
////                DrawPropertyOrOverride(_worldModel, t.worldModel, overrides);
////                
////                UnityEditor.Editor.CreateCachedEditor(t.worldModel, null, ref modelPreviewEditor);
////                modelPreviewEditor?.OnInteractivePreviewGUI(GUILayoutUtility.GetRect(500, 250), UnityEditor.EditorStyles.helpBox);
////            }
////            
////            EditorGUILayout.LabelField(new GUIContent("Item specific"), General2.Editors.EditorStyles.titleStyle);
////            using (new VerticalLayoutBlock(General2.Editors.EditorStyles.boxStyle))
////            {
////                DrawPropertiesExcluding(serializedObject, overrides.Keys.Concat(properties.Select(o => o.Name)).ToArray());
////            }
////
////            EditorGUILayout.LabelField(new GUIContent("Logistics"), General2.Editors.EditorStyles.titleStyle);
////            using (new VerticalLayoutBlock(General2.Editors.EditorStyles.boxStyle))
////            {
////                DrawPropertyOrOverride(_layoutShape, t.layoutShape, overrides);
////                DrawPropertyOrOverride(_maxStackSize, t.maxStackSize, overrides);
//////                _maxStackSize.intValue = Mathf.Clamp(_maxStackSize.ValueEntry., 1, 9999);
////                
////                DrawPropertyOrOverride(_weight, t.weight, overrides);
//////                _weight.floatValue = Mathf.Clamp(_weight.floatValue, 0f, 9999f);
////            }
////            
////            EditorGUILayout.LabelField(new GUIContent("Financial"), General2.Editors.EditorStyles.titleStyle);
////            using (new VerticalLayoutBlock(General2.Editors.EditorStyles.boxStyle))
////            {
//////                if (_buyPrice.arraySize == 0)
//////                {
//////                    GUI.color = new Color(1f, 0.6f, 0f, GUI.color.a);
//////                }
////                DrawPropertyOrOverride(_buyPrice, t.buyPrice, overrides);
//////                GUI.color = Color.white;
////                
////                
//////                if (_sellPrice.arraySize == 0)
//////                {
//////                    GUI.color = new Color(1f, 0.6f, 0f, GUI.color.a);
//////                }
////                DrawPropertyOrOverride(_sellPrice, t.sellPrice, overrides);
//////                GUI.color = Color.white;
////
////            }
////            
//////            DoDrawWithOrder(40, 49);
//////            base.OnInspectorGUI();
////        }
//    }
//}
//
//#endif