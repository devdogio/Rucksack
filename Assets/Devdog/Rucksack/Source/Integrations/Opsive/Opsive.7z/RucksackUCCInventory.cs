﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Devdog.Rucksack.CharacterEquipment;
using Devdog.Rucksack.CharacterEquipment.Items;
using UnityEngine;
using Devdog.Rucksack.Collections;
using Devdog.Rucksack.Database;
using Devdog.Rucksack.Items;
using Opsive.UltimateCharacterController.Inventory;
using Opsive.UltimateCharacterController.Items;

namespace Devdog.Rucksack.Integrations.UltimateCharacterController
{
	public class RucksackUCCInventory : InventoryBase
	{
		[SerializeField]
		protected UnityItemDefinitionDatabase itemsDatabase;

		[SerializeField]
		protected string collectionName;

		[SerializeField]
		private int _collectionSlotCount = 12;

		[SerializeField]
		protected string equipmentCollectionName;

		[SerializeField]
		private int _equipmentCollectionSlotCount = 4;
		
//		protected Dictionary<ItemType, IRucksackUCCItemInstance>[] uccItemTypeItemMap;
		private Dictionary<ItemType, Item>[] _itemTypeItemMap;
		protected Dictionary<ItemType, IRucksackUCCItemDefinition> uccItemTypeToItemDefinitionMap;
		private Item[] _activeItem;
		
		protected Collections.ICollection<IItemInstance> backingCollection;
		protected Collections.ICollection<IEquippableItemInstance> equipmentCollection;

		protected IEquippableCharacter<IEquippableItemInstance> equipment;
		protected ILogger logger;

		public RucksackUCCInventory()
		{
			logger = new UnityLogger("[Rucksack][UCC] ");
			
		}

		protected override void Awake()
		{
			base.Awake();
			equipment = GetComponent<IEquippableCharacter<IEquippableItemInstance>>();
			if (equipment == null)
			{
				logger.Error("No IEquippableCharacter<IEquippableItemInstance> found on player", this);
			}

			var col = new Collection<IItemInstance>(_collectionSlotCount, logger);
			col.collectionName = collectionName;
			CollectionRegistry.byName.Register(collectionName, col);
			backingCollection = col;

			var equip = new EquipmentCollection<IEquippableItemInstance>(_equipmentCollectionSlotCount, equipment, logger);
			equip.collectionName = equipmentCollectionName;
			CollectionRegistry.byName.Register(equipmentCollectionName, equip);
			equipmentCollection = equip;
			

			_itemTypeItemMap = new Dictionary<ItemType, Item>[SlotCount];
			for (int i = 0; i < SlotCount; ++i) {
				_itemTypeItemMap[i] = new Dictionary<ItemType, Item>();
			}
			_activeItem = new Item[SlotCount];
			

			
			uccItemTypeToItemDefinitionMap = new Dictionary<ItemType, IRucksackUCCItemDefinition>();
			foreach (var item in itemsDatabase.GetAll().result)
			{
				var i = item as IRucksackUCCItemDefinition;
				if (i != null && i.uccItem != null)
				{
					uccItemTypeToItemDefinitionMap[i.uccItem] = i;
				}
			}
			logger.LogVerbose($"Indexed {uccItemTypeToItemDefinitionMap.Count} mappings between Rucksack and UCC", this);
		}

		protected override bool AddItemInternal(Item item)
		{
			if (item.ItemType == null) {
				logger.Error($"Error: Item {item} has no ItemType");
				return false;
			}

			var index = GetIndex(backingCollection, item);
			if (index == -1 || backingCollection.GetAmount(index) + 1 > backingCollection[index].maxStackSize)
			{
				logger.LogVerbose($"Adding item of type: ${item.ItemType} to inventory", this);
				var inst = (IRucksackUCCItemInstance)ItemFactory.CreateInstance(uccItemTypeToItemDefinitionMap[item.ItemType], System.Guid.NewGuid());
				inst.uccItemInstance = item;
				inst.uccItemType = item.ItemType;
				
				var added = backingCollection.Add(inst);
				logger.Error("", added.error);
				return added.error == null;
			}
			
			var set = backingCollection.Set(index, backingCollection[index], backingCollection.GetAmount(index) + 1);
			logger.Error("", set.error);
			return set.error == null;
		}

		protected override bool PickupItemTypeInternal(ItemType itemType, float count)
		{
			IRucksackUCCItemDefinition def;
			if (uccItemTypeToItemDefinitionMap.TryGetValue(itemType, out def) == false)
			{
				logger.Warning("Couldn't find ucc item type to Rucksack item definition mapping for item type " + itemType, this);
				return false;
			}
			
			var index = GetIndex(backingCollection, itemType);
			if (index == -1)
			{
				var inst = (IRucksackUCCItemInstance)ItemFactory.CreateInstance(def, System.Guid.NewGuid());
				inst.uccItemType = itemType;

				var added = backingCollection.Add(inst, Mathf.FloorToInt(count));
				logger.Error("", added.error);
				return added.error == null;
			}
			
			var set = backingCollection.Set(index, backingCollection[index], Mathf.FloorToInt(Mathf.Clamp(backingCollection.GetAmount(index) + count, 0, itemType.Capacity)));
			logger.Error("", set.error);
			return set.error == null;
		}
		
		protected override float GetItemTypeCountInternal(ItemType itemType)
		{
			return backingCollection.GetAmount(o => o is IRucksackUCCItemInstance);
		}

		protected override void UseItemInternal(ItemType itemType, float count)
		{
			var index = GetIndex(backingCollection, itemType);
			if (index == -1)
			{
				Debug.LogError("Error: Trying to use item " + itemType.name + " when the ItemType doesn't exist.");
				return;
			}

			var set = backingCollection.Set(index, backingCollection[index], backingCollection.GetAmount(index) - Mathf.FloorToInt(count));
			logger.Error("", set.error);
		}

		protected override Item GetItemInternal(int slotID)
		{
			var item = backingCollection.Where(o => o is IRucksackUCCItemInstance).Cast<IRucksackUCCItemInstance>().FirstOrDefault(o => o.isActive);
			if (item != null)
			{
				return item.uccItemInstance;
			}

			return null;
		}

		protected override Item GetItemInternal(int slotID, ItemType itemType)
		{
			var item = backingCollection.Where(o => o is IRucksackUCCItemInstance).Cast<IRucksackUCCItemInstance>().FirstOrDefault(o => o.uccItemType == itemType);
			if (item != null)
			{
				return item.uccItemInstance;
			}

			return null;
		}
		
		/// <summary>
		/// Internal method which removes the ItemType from the inventory.
		/// </summary>
		/// <param name="itemType">The ItemType to remove.</param>
		/// <param name="slotID">The ID of the slotID.</param>
		/// <returns>The item that was removed (can be null).</returns>
		protected override Item RemoveItemTypeInternal(ItemType itemType, int slotID)
		{
			if (slotID == -1) {
				return null;
			}

			var index = GetIndex(backingCollection, itemType, slotID);
			if (index == -1)
			{
				return null;
			}

			var item = (IRucksackUCCItemInstance)backingCollection[index];
			backingCollection.Set(index, backingCollection[index], backingCollection.GetAmount(index) - 1);
			
			// The item should no longer be equipped.
			if (_activeItem[slotID] != null && _activeItem[slotID].ItemType == itemType) {
				_activeItem[slotID] = null;
			}

			return item.uccItemInstance;
		}
		
		
		
		#region Equipment 
		
		protected override Item EquipItemInternal(ItemType itemType, int slotID)
		{
			// TODO: Remove from inventory?? (make optional perhaps)

			var item = backingCollection.Where(o => o is IRucksackUCCItemInstance).Cast<IRucksackUCCItemInstance>().FirstOrDefault(o => o.uccItemType == itemType && o.slotID == slotID);
			if (item != null)
			{
				var equipped = equipment.EquipAt(slotID, item, item.collectionEntry.amount);
				if (equipped.error != null)
				{
					logger.Error("Couldn't equip item with error: " + equipped, this);
					return null;
				}
				
				_activeItem[slotID] = item.uccItemInstance;
				item.isActive = true;
				
				return item.uccItemInstance;
			}

			logger.Error("Couldn't equip itemType " + itemType + " in slot " + slotID, this);
			return null;
		}

		protected override Item UnequipItemInternal(int slotID)
		{
			var item = equipmentCollection[slotID] as IRucksackUCCItemInstance;
			var unEquipped = equipment.UnEquipAt(slotID);

			if (unEquipped.error != null)
			{
				logger.Warning("Failed to un-equip item with error: " + unEquipped, this);
				return null;
			}

			if (item != null)
			{
				return item.uccItemInstance;
			}

//			logger.Error("Couldn't un-equip item in slot " + slotID, this);
			return null;
		}

		
		#endregion

		
		protected static int GetIndex(Collections.ICollection<IItemInstance> collection, Item item)
		{
			return collection.IndexOf((o) =>
			{
				var uccItem = o as IRucksackUCCItemInstance;
				if (uccItem == null)
				{
					return false;
				}

				return uccItem.uccItemInstance == item;
			});
		}

		protected static int GetIndex(Collections.ICollection<IItemInstance> collection, ItemType item)
		{
			return collection.IndexOf((o) =>
			{
				var uccItem = o as IRucksackUCCItemInstance;
				if (uccItem == null)
				{
					return false;
				}

				if (uccItem.uccItemType == item)
				{
					return true;
				}

				if (uccItem.uccItemInstance != null && uccItem.uccItemInstance.ItemType == item)
				{
					return true;
				}

				return false;
			});
		}
		
		protected static int GetIndex(Collections.ICollection<IItemInstance> collection, ItemType item, int slotID)
		{
			return collection.IndexOf((o) =>
			{
				var uccItem = o as IRucksackUCCItemInstance;
				if (uccItem == null)
				{
					return false;
				}
				
				if (uccItem.uccItemType == item)
				{
					return true;
				}

				if (uccItem.slotID == slotID && uccItem.uccItemInstance != null && uccItem.uccItemInstance.ItemType == item)
				{
					return true;
				}

				return false;
			});
		}


//		protected static IEnumerable<IRucksackUCCItemInstance> FindItems(ItemType itemType, Devdog.Rucksack.Collections.ICollection<IItemInstance> col)
//		{
//			foreach (var item in col)
//			{
//				var instance = item as IRucksackUCCItemInstance;
//				if (instance != null && instance.uccItemInstance != null && instance.uccItemInstance.ItemType == itemType)
//				{
//					yield return instance;
//				}
//			}
//		}
	}
}
