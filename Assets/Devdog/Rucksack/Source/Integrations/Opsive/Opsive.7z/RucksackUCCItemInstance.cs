using System;
using Devdog.General2;
using Devdog.Rucksack.CharacterEquipment;
using Devdog.Rucksack.CharacterEquipment.Items;
using Devdog.Rucksack.Items;
using Opsive.UltimateCharacterController.Inventory;
using Opsive.UltimateCharacterController.Items;

namespace Devdog.Rucksack.Integrations.UltimateCharacterController
{
    public class RucksackUCCItemInstance : UnityItemInstance, IRucksackUCCItemInstance, IEquatable<RucksackUCCItemInstance>
    {
        public Item uccItemInstance { get; set; }
        public ItemType uccItemType { get; set; }
        
        public IEquipmentCollection<IEquippableItemInstance> equippedTo {
            get { return collectionEntry?.collection as IEquipmentCollection<IEquippableItemInstance>; }
        }

        public new IEquippableItemDefinition itemDefinition { get; }
        public IEquipmentType equipmentType
        {
            get { return itemDefinition.equipmentType; }
        }
        
        public override int maxStackSize
        {
            get
            {
                return itemDefinition.maxStackSize;
//                var stackSize = Mathf.FloorToInt(uccItemInstance.ItemType.Capacity);
//                if (stackSize <= 0)
//                {
//                    return 1;
//                }
//                return stackSize;
            }
        }

        public int slotID
        {
            get { return uccItemInstance.SlotID; }
            set { uccItemInstance.SlotID = value; }
        }

        public bool isActive
        {
            get { return uccItemInstance.IsActive(); }
            set
            {
                uccItemInstance.SetVisibleObjectActive(value);
                uccItemInstance.ActivePerspectiveItem.SetActive(value);
            }
        }

        protected RucksackUCCItemInstance()
        { }

        public RucksackUCCItemInstance(Guid ID, IRucksackUCCItemDefinition itemDefinition)
            : base(ID, itemDefinition)
        {
            this.itemDefinition = itemDefinition;
        }

        public static bool operator ==(RucksackUCCItemInstance left, RucksackUCCItemInstance right)
        {
            return Equals(left, right);
        }

        public static bool operator !=(RucksackUCCItemInstance left, RucksackUCCItemInstance right)
        {
            return !Equals(left, right);
        }
        
        public override Result<ItemUsedResult> DoUse(Character character, ItemContext useContext)
        {
            uccItemInstance.StartEquip(true);
            return new ItemUsedResult(1, false, 0f);
        }

        public virtual void OnEquipped(int index, IEquipmentCollection<IEquippableItemInstance> collection)
        {
            
        }

        public virtual void OnUnEquipped(int index, IEquipmentCollection<IEquippableItemInstance> collection)
        {
            
        }
        
        public bool Equals(RucksackUCCItemInstance other)
        {
            return ID == other?.ID;
        }

        public bool Equals(IEquippableItemInstance other)
        {
            throw new NotImplementedException();
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            if (ReferenceEquals(this, obj)) return true;
            if (obj.GetType() != this.GetType()) return false;
            return Equals((RucksackUCCItemInstance) obj);
        }

        public override int GetHashCode()
        {
            return ID.GetHashCode();
        }
    }
}