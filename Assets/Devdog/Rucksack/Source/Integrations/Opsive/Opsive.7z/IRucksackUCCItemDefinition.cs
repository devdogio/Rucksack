using Devdog.Rucksack.Items;
using Opsive.UltimateCharacterController.Inventory;
using UnityEngine;

namespace Devdog.Rucksack.Integrations.UltimateCharacterController
{
    public interface IRucksackUCCItemDefinition : IUnityEquippableItemDefinition
    {
        ItemType uccItem { get; }
    }
}