using Devdog.General2;
using Devdog.Rucksack.CharacterEquipment;
using Devdog.Rucksack.Items;
using Opsive.UltimateCharacterController.Inventory;
using UnityEngine;

namespace Devdog.Rucksack.Integrations.UltimateCharacterController
{
    public class RucksackUCCItemDefinition : UnityItemDefinition, IRucksackUCCItemDefinition
    {
        [Required]
        [SerializeField]
        private UnityEquipmentType _equipmentType;
        public IEquipmentType equipmentType
        {
            get { return this.GetUnityObjectValue(o => o._equipmentType); }
        }

        [SerializeField]
        private string _mountPoint;
        public string mountPoint
        {
            get { return this.GetValue(o => o._mountPoint, ""); }
        }

        [SerializeField]
        private GameObject _equipmentModel;

        /// <summary>
        /// The model used for equipping the item to your character.
        /// <remarks>Uses `base.worldModel` if no _equipmentModel is set.</remarks>
        /// </summary>
        public virtual GameObject equipmentModel
        {
            get { return this.GetUnityObjectValue(o => o._equipmentModel) ?? worldModel; }
        }
        
        [SerializeField]
        private ItemType _uccItem;
        public ItemType uccItem
        {
            get
            {
                return this.GetValue(o => o._uccItem);
            }
        }
    }
}