using Devdog.Rucksack.CharacterEquipment.Items;
using Devdog.Rucksack.Items;
using Opsive.UltimateCharacterController.Inventory;
using Opsive.UltimateCharacterController.Items;

namespace Devdog.Rucksack.Integrations.UltimateCharacterController
{
    public interface IRucksackUCCItemInstance : IUnityItemInstance, IEquippableItemInstance
    {
//        Item uccItemDefinition { get; }
        
        Item uccItemInstance { get; set; }
        ItemType uccItemType { get; set; }
        int slotID { get; set; }
        bool isActive { get; set; }
    }
}