using Devdog.Rucksack.Items;
using UnityEngine;

namespace Devdog.Rucksack.Integrations.UltimateCharacterController
{
    [ExecuteInEditMode]
    public sealed class UCCItemFactory : MonoBehaviour
    {
        private void Awake()
        {
            ItemFactory.Bind<RucksackUCCItemDefinition, RucksackUCCItemInstance>();
        }
    }
}