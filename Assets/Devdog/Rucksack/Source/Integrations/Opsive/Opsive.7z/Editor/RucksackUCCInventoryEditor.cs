﻿using UnityEngine;
using UnityEditor;
using UnityEditorInternal;

namespace Devdog.Rucksack.Integrations.UltimateCharacterController.Editor
{
    /// <summary>
    /// Custom inspector for the InventoryBase component.
    /// </summary>
    [CustomEditor(typeof(RucksackUCCInventory), true)]
    public class InventoryBaseInspector : UnityEditor.Editor
    {
        /// <summary>
        /// Draws the inspector.
        /// </summary>
        public override void OnInspectorGUI()
        {
            base.OnInspectorGUI();


        }
    }
}